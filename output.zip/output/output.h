#ifdef __OUTPUT_H__
#define __OUTPUT_H__
/*
 * @brief   message_sink(): 
 *          Prints the Gantt Chart.
 *          Called every time a job is scheduled or completes.
 * 
 * @params  int pid:
 *          The process id is passed here.
 * 
 *          int end_time:
 *          The time instant this function was called.
 * 
 *          int action: 
 *          Takes value either `0` or `1`
 *          Action is either taking a process off ready queue - `0`
 *          Or a process being completed - `1`
 * 
 * @return  None            
 */
void message_sink(int pid, int end_time, int action);

/*
 * @brief print_output_stat():
 *        Prints average waiting time and average turnaround time. Called twice. 
 *        First usage-->print_output_stat(dispatcher.num_jobs, NULL)
 *        in order to declare the array size inside the function.
 *        Second time-->print_output_stat(0, job). 
 *        The job information is then added onto the previous info to calculate avg. waiting
 *        time and avg.turnaround time.
 * 
 * @params  int num_jobs:
 *          Number of total jobs. This is also the number of times this function
 *          shall be called.
 * 
 *          void *job:
 *          The job that has just completed.         
 */
void print_output_stat(int num_jobs, void *job_completed);
#endif
